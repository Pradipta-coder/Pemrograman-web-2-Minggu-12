
	<script src="<?php echo base_url('assets/jquery/jquery-1.12.0.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
</body>
</html>